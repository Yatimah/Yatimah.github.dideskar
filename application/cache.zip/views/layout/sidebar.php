<?php
if ($this->session->userdata('role_id') == 3) {
    //get notifikasi
    $sku = $this->M_notifikasi->nSku();
    $skdu = $this->M_notifikasi->nSkdu();
    $skd = $this->M_notifikasi->nSkd();
    $skbn = $this->M_notifikasi->nSkbn();
    $skp = $this->M_notifikasi->nSkp();

    //jumlah data notifikasi surat users
    $all = $sku['jumlah'] + $skdu['jumlah'] + $skd['jumlah'] + $skbn['jumlah'] + $skp['jumlah'];
}

if ($this->session->userdata('role_id') == 1 || $this->session->userdata('role_id') == 2) {
    //get notifikasi admin
    $Sku = $this->M_notifikasi->aSku();
    $Skdu = $this->M_notifikasi->aSkdu();
    $Skd = $this->M_notifikasi->aSkd();
    $Skbn = $this->M_notifikasi->aSkbn();
    $Skp = $this->M_notifikasi->aSkp();

    $adminAll = $Sku['jumlah'] + $Skdu['jumlah'] + $Skd['jumlah'] + $Skbn['jumlah'] + $Skp['jumlah'];
}

?>
<div id="sidebar" class='active'>
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            <img src="<?= base_url() ?>./assets/logo/asett.jpg" width="100%" height="100%">
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <!-- <li class='sidebar-title'>Main Menu</li> -->
                <?php if ($this->session->userdata('role_id') == 1 || $this->session->userdata('role_id') == 2 || $this->session->userdata('role_id') == 3) { ?>
                    <li class="sidebar-item <?= $this->uri->segment(1) == 'dashboard' ? 'active ' : '' ?>">
                        <a href="<?= base_url('dashboard') ?>" class='sidebar-link'>
                            <i class="bi bi-speedometer"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                <?php } ?>
                <?php if ($this->session->userdata('role_id') == 1) { ?>
                    <li class="sidebar-item  has-sub">
                        <a href="#" class='sidebar-link'>
                            <i class="bi bi-envelope-check-fill"></i>
                            <span>Verifikasi Surat</span>
                            <span class="badge badge bg-danger text-white"><?= $adminAll; ?></span>
                        </a>
                        <ul class="submenu
                        <?=
                            $this->uri->segment(1) == 'verifikasi-surat-keterangan-usaha' ||
                            $this->uri->segment(1) == 'verifikasi-surat-keterangan-domisili-usaha' ||
                            $this->uri->segment(1) == 'verifikasi-surat-keterangan-domisili' ||
                            $this->uri->segment(1) == 'verifikasi-surat-keterangan-beda-nama' ||
                            $this->uri->segment(1) == 'verifikasi-surat-keterangan-pemakaman' ||
                            $this->uri->segment(1) == 'verifikasi-surat-pemakaman' 
                            ? 'active ' : ''
                        ?>">
                            
                            <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-usaha') ?>">Surat Keterangan Usaha
                                    <span class="badge badge bg-danger text-white"><?= $Sku['jumlah'] ?></span>
                                </a>
                            </li>
                            
                             <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-domisili-usaha') ?>">Surat Keterangan Domisili Usaha
                                    <span class="badge badge bg-danger text-white"><?= $Skdu['jumlah'] ?></span>
                                </a>
                            </li>
                            
                            
                             <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-domisili') ?>">Surat Keterangan Domisili 
                                    <span class="badge badge bg-danger text-white"><?= $Skd['jumlah'] ?></span>
                                </a>
                            </li>
                            
                            
                             <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-beda-nama') ?>">Surat Keterangan Beda Nama 
                                    <span class="badge badge bg-danger text-white"><?= $Skbn['jumlah'] ?></span>
                                </a>
                            </li>
                            
                            
                             <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-pemakaman') ?>">Surat Keterangan Pemakaman
                                    <span class="badge badge bg-danger text-white"><?= $Skp['jumlah'] ?></span>
                                </a>
                            </li>
                        </ul> 
                    </li> 

                    <li class="sidebar-item  <?= $this->uri->segment(1) == 'data-warga' || $this->uri->segment(1) == 'tambah-data-warga' || $this->uri->segment(1) == 'edit-warga' || $this->uri->segment(1) == 'detail-warga' ? 'active ' : '' ?>">
                        <a href="<?= base_url('data-warga') ?>" class='sidebar-link'>
                            <i class="bi bi-people-fill"></i>
                            <span>Data Warga</span>
                        </a>
                    </li>
                    <li class="sidebar-item  <?= $this->uri->segment(1) == 'data-users' ? 'active ' : '' ?>">
                        <a href="<?= base_url('data-users') ?>" class='sidebar-link'>
                            <i class="bi bi-person-lines-fill"></i>
                            <span>Data Users</span>
                        </a>
                    </li>
                    <li class="sidebar-item  <?= $this->uri->segment(1) == 'data-administrator' ? 'active ' : '' ?>">
                        <a href="<?= base_url('data-administrator') ?>" class='sidebar-link'>
                            <i class="bi bi-person-circle"></i>
                            <span>Administrator</span>
                        </a>
                    </li>

                <?php } else if ($this->session->userdata('role_id') == 2) { ?>
                    <li class="sidebar-item  has-sub">
                        <a href="#" class='sidebar-link'>
                            <i class="bi bi-envelope-check-fill"></i>
                            <span>Verifikasi Surat</span>
                            <span class="badge badge bg-danger text-white"><?= $adminAll; ?></span>
                        </a>
                        <ul class="submenu
                        <?=
                        $this->uri->segment(1) == 'verifikasi-surat-keterangan_usaha' ||
                            $this->uri->segment(1) == 'verifikasi-surat-keterangan-domisili-usaha' ||
                            $this->uri->segment(1) == 'verifikasi-surat-keterangan-domisili' ||
                            $this->uri->segment(1) == 'verifikasi-surat-keterangan-beda-nama' ||
                            $this->uri->segment(1) == 'verifikasi-surat-keterangan-pemakaman' ||
                            $this->ugment(1) == 'verifikasi-surat-pemakaman'
                            ? 'active ' : ''
                        ?>">
                            <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-usaha') ?>">Surat Keterangan Usaha
                                    <span class="badge badge bg-danger text-white"><?= $Sku['jumlah'] ?></span></a>
                            </li>
                            <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-domisili-usaha') ?>">Surat Keterangan Domisili Usaha
                                    <span class="badge badge bg-danger text-white"><?= $Skdu['jumlah'] ?></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-domisili') ?>">Surat Keterangan Domisili
                                    <span class="badge badge bg-danger text-white"><?= $Skd['jumlah'] ?></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-beda-nama') ?>">Surat Keterangan Beda Nama
                                    <span class="badge badge bg-danger text-white"><?= $Skbn['jumlah'] ?></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('verifikasi-surat-keterangan-pemakaman') ?>">Surat Keterangan Pemakaman
                                    <span class="badge badge bg-danger text-white"><?= $Skp['jumlah'] ?></span>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php } else if ($this->session->userdata('role_id') == 3) {  ?>
                    <li class="sidebar-item  <?= $this->uri->segment(1) == 'list-surat' ? 'active' : '' ?>">
                        <a href="<?= base_url('list-surat') ?>" class='sidebar-link'>
                            <i class="bi bi-envelope-plus-fill"></i>
                            <span>Layanan Surat</span>
                        </a>
                    </li>
                     <li class="sidebar-item  <?= $this->uri->segment(1) == 'histori-surat' ? 'active' : '' ?>">
                        <a href="<?= base_url('histori-surat') ?>" class='sidebar-link'>
                            <i class="bi bi-clock-history"></i>
                            <span>Surat</span>
                            <span class="badge badge bg-danger text-white"><?= $all ?></span>
                        </a>
                    </li>
                <?php } ?>
            </ul>
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div>

<div id="main">
    <nav class="navbar navbar-header navbar-expand navbar-light">
        <a class="sidebar-toggler" href="#"><span class="navbar-toggler-icon"></span></a>
        <button class="btn navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <h4 style="margin-left:10px; margin-top:15px;">Aplikasi Pelayanan Surat</h4>
            <ul class="navbar-nav d-flex align-items-center navbar-light ml-auto">
                <li class="dropdown">
                    <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                        <div class="avatar mr-1">
                            <img src="<?= base_url(); ?>./assets/images/avatar/avatar-s-1.png" alt="" srcset="">
                        </div>
                        <div class="d-none d-md-block d-lg-inline-block">Hi, <?= $this->session->userdata('nama') ?></div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <!-- <a class="dropdown-item" href="#"><i data-feather="user"></i> Account</a>
                        <a class="dropdown-item" href="#"><i data-feather="settings"></i> Settings</a>
                        <div class="dropdown-divider"></div> -->
                        <a class="dropdown-item" href="<?= base_url('logout') ?>"><i data-feather="log-out"></i> Logout</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>